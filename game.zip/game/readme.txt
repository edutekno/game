Readme has moved online to https://www.ritlabs.com/en/products/tinyweb/
